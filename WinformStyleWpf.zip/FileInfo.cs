﻿using Microsoft.Toolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinformStyleWpf
{
    public class FileInfo : ObservableObject
    {
        private string _path;

        public string Path
        {
            get { return _path; }
            set { SetProperty(ref _path, value); }
        }

        private string _name;

        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value); }
        }
        private bool _isUploaded;

        public bool IsUploaded
        {
            get { return _isUploaded; }
            set { SetProperty(ref _isUploaded, value); }
        }

    }
}
