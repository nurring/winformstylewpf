﻿using Microsoft.Toolkit.Mvvm.Input;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WinformStyleWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public IList<FileInfo> FileInfos { get; set; }

        public ICommand FileOpenCommand { get; set; }

        public ICommand UploadCommand { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            FileOpenCommand = new RelayCommand<FileInfo>(OnFileOpen);
            UploadCommand = new RelayCommand(OnUpload);

            FileInfos = new List<FileInfo>();
            for (int i = 0; i < 20; i++)
            {
                FileInfos.Add(new FileInfo());
            }
            FileDataGrid.ItemsSource = FileInfos;
        }

        private async void OnUpload()
        {
            foreach (var file in FileInfos
                .Where(f => string.IsNullOrEmpty(f.Name) == false))
            {
                await Task.Delay(1000);
                file.IsUploaded = true;
            }
            Debug.WriteLine("Work completed");
        }

        private void OnFileOpen(FileInfo fileInfo)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                fileInfo.Name = System.IO.Path.GetFileName(openFileDialog.FileName);
                fileInfo.Path = openFileDialog.FileName;
            }
        }
    }
}
